package edu.psu.ab.ist.sworks.pojo;

public class MissionConfs {
}
