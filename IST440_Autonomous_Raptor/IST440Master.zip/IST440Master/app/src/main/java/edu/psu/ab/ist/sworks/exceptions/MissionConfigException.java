package edu.psu.ab.ist.sworks.exceptions;

public class MissionConfigException extends Exception {

    public MissionConfigException(String message)
    {
        super(message);
    }
}
