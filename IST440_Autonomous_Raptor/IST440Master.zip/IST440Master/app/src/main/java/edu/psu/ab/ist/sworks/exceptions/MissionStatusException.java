package edu.psu.ab.ist.sworks.exceptions;

public class MissionStatusException extends Exception {

    public MissionStatusException(String message)
    {
        super(message);
    }
}
