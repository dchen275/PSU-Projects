package edu.psu.ab.ist.sworks.exceptions;

public class MissionCaptureException extends Exception {

    public MissionCaptureException(String message)
    {
        super(message);
    }
}
